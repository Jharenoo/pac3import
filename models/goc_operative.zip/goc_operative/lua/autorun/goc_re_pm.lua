player_manager.AddValidModel( "XV Global Occult Coalition", "models/player/xuvon/xuvon_goc_re_base.mdl" )
player_manager.AddValidHands( "XV Global Occult Coalition", "models/weapons/xuvon/xuvon_goc_re_arms.mdl", 0, "00000000" )

/*ya sosal menya ebali*/